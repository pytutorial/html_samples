// Kiểu dữ liệu object
/*var product = {
    code: 'IPX',
    name: 'IPhone X',
    price: 12.5
}
console.log(product.name);
*/

var productList = [
    {'code': 'IPX', name: 'IPhone X', price: 12.5},
    {code: 'IP8', name: 'IPhone 8', price: 8.5},
    {code: 'S4', name: 'Galaxy S4', price: 10.5}
];
var keyword = 'IPhone';
var result = [];
for(var i = 0; i < productList.length; i++) {
    var p = productList[i];    
    if(p.name.includes(keyword)){
        result.push(p);
    }
}
// Python: result = [p for p in productList if keyword in p['name']]

var result = productList.filter(p => p.name.includes(keyword));
console.log(result);
