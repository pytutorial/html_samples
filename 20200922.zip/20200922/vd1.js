// Khai báo biến, câu lệnh
var x = 1;
var y = 2;
var z = x + y;
console.log(`${x}+${y}=${z}`);