// Kiểu dữ liệu list
var lst = [1, 2, 3, 4, 5, 6, 7, 8];
var s = 0;
for(var i = 0; i < lst.length; i++) {
    s += lst[i];
}
console.log(s);
