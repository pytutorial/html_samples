// Kiểu dữ liệu object

var orders = [
    {product: 'IPX', price: 12.5, qty: 2},
    {product: 'S4', price: 10.5, qty:1},
    {product: 'S3', price: 8.5, qty:3}
];
var revenues = orders.map(o => ({
        product: o.product,
        revenue: o.qty*o.price
    }));
console.log(revenues);