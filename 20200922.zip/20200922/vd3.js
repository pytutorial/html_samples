// Vòng lặp for
for(var i = 0; i < 10; i++) {
    console.log(`${i}*${i}=${i*i}`);
}
for(var i = 2; i < 10; i++) {
    for(var j=2; j < 10; j++) {
        console.log(`${i}*${j}=${i*j}`);
    }
    console.log();
}