// Kiểu dữ liệu list
var lst1 = [1, 2, 3, 4, 5, 6, 7];
var lst2 = [ 1, 3, 5, 7];
//TODO: Tạo ra 1 list từ lst1 mà ko thuộc lst2
var result = [];
for(var i = 0; i < lst1.length; i++) {
    if(! lst2.includes(lst1[i])){
        result.push(lst1[i]);
    }
}
console.log(result);