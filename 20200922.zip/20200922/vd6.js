// Function, lambda
function square(x) {
    return x*x;
}

var lst = [1, 2, 3, 4];
var lst2 = [];
for(var i = 0; i < lst.length; i++) {
    lst2.push(square(lst[i]));
}
lst2 = lst.map(x => x*x);
console.log(lst2);