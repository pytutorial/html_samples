// Xử lý string

var ho = 'Nguyễn', ten_dem='Văn', ten='An';
var ho_ten = ho + ' ' + ten_dem + ' ' + ten;
var ho_ten = `${ho} ${ten_dem} ${ten}`;

console.log(ho_ten);